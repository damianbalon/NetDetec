﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NetDetect
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void SendPingAsync(string address, int timeout, byte[] buffor, PingOptions options)
        {
            Ping ping = new Ping();
            ping.PingCompleted += new PingCompletedEventHandler(EndPing);

            try
            {
                ping.SendAsync(address, timeout, buffor, options, null);
            }
            catch (Exception ex)
            {
                lbx1.Items.Add(ex.Message);
            }
        }

        public void EndPing(object sender, PingCompletedEventArgs e)
        {
            if (e.Cancelled || e.Error != null)
            {
                lbx1.Items.Add("Błąd: operacja przerwana");
                ((IDisposable)(Ping)sender).Dispose();
                return;
            }
            PingReply reply = e.Reply;
            if (reply.Status == IPStatus.Success)
            {
                lbx1.Items.Add(reply.Address + ": bajtów=" + reply.Buffer.Length + ", czas=" + reply.RoundtripTime + "ms, ttl=" + reply.Options.Ttl);
            }

            ((IDisposable)(Ping)sender).Dispose();

        }

        private void btnScan_Click(object sender, RoutedEventArgs e)
        {
            IPAddress startIP = null;
            IPAddress endIP = null;

            lbx1.Items.Clear();

            try
            {
                startIP = IPAddress.Parse(tbxStartIP.Text);
                endIP = IPAddress.Parse(tbxEndIP.Text);
            }
            catch
            {
                MessageBox.Show("Błędnie wprowadzony adres");
                return;
            }

            byte[] start = startIP.GetAddressBytes();
            byte[] end = endIP.GetAddressBytes();

            PingOptions options = new PingOptions();
            options.Ttl = 128;
            options.DontFragment = true;
            string data = "aaaaaaaaaaaaaaaaaaaaa";
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            int timeout = 120;

            for (uint i = BitConverter.ToUInt32(start.Reverse().ToArray(), 0); i <= BitConverter.ToUInt32(end.Reverse().ToArray(), 0); i++)
            {
                byte[] bytes = BitConverter.GetBytes(i).Reverse().ToArray();
                IPAddress address = new IPAddress(bytes);
                SendPingAsync(address.ToString(), timeout, buffer, options);
            }
        }

    }
}

